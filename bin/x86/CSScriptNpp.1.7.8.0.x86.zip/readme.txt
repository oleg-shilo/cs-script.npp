'CS-Script' (CSScriptNpp.dll) - The plugin for CS-Script integration with Notepad++ 
(part of CS-Script Notepad++ tools suite 'CS-Script.Npp')
--------------------------------------------------------------
1. System Requirements
'CS-Script' requires .NET 4.0 or higher.

2. Installation
To install plugin unpack the content of the CSScriptNpp.zip in the Notepad++ plugin directory.

3. Usage
Typically user opens the C# file with Notepad++ and then presses 'Load' button on the CS-Script toolbar.  
After that the all features can be accessed through two Notepad++ dockable panels Project and Output panel. 

See www.csscript.net/npp/csscript.html for more details