﻿using System;
using System.Runtime.InteropServices;
using Kbg.NppPluginNET;
using Kbg.NppPluginNET.PluginInfrastructure;
using System.Reflection;

public class NppPluginBinder
{
    static public void bind(string hostAssemblyFile)
    {
        Assembly.LoadFrom(hostAssemblyFile); // to avoid complicated probing scenarios
    }
}

namespace MyNppPlugin
{
    public class UnmanagedExports : IUnmanagedExports
    {
        public bool isUnicode()
        {
            return true;
        }

        public void setInfo(NppData notepadPlusData)
        {
            PluginBase.nppData = notepadPlusData;
            Main.CommandMenuInit();
        }

        public IntPtr getFuncsArray(ref int nbF)
        {
            nbF = PluginBase._funcItems.Items.Count;
            return PluginBase._funcItems.NativePointer;
        }

        public uint messageProc(uint Message, IntPtr wParam, IntPtr lParam)
        {
            return 1;
        }

        IntPtr _ptrPluginName = IntPtr.Zero;

        public IntPtr getName()
        {
            if (_ptrPluginName == IntPtr.Zero)
                _ptrPluginName = Marshal.StringToHGlobalUni(Main.PluginName);
            return _ptrPluginName;
        }

        public void beNotified(IntPtr notifyCode)
        {
            ScNotification notification = (ScNotification)Marshal.PtrToStructure(notifyCode, typeof(ScNotification));
            if (notification.Header.Code == (uint)NppMsg.NPPN_TBMODIFICATION)
            {
                PluginBase._funcItems.RefreshItems();
                Main.SetToolBarIcon();
            }
            else if (notification.Header.Code == (uint)NppMsg.NPPN_SHUTDOWN)
            {
                Main.PluginCleanUp();
                Marshal.FreeHGlobal(_ptrPluginName);
            }
            else
            {
                Main.OnNotification(notification);
            }
        }
    }
}