using System;
using System.Linq;
using Kbg.NppPluginNET.PluginInfrastructure;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows.Forms;

namespace MyNppPlugin
{
    public static class NppExtensions
    {
        static public void ShowDockableDialog(this NotepadPPGateway editor, IntPtr dialogHandle)
        {
            Win32.SendMessage(editor.Handle, (uint)NppMsg.NPPM_DMMSHOW, 0, dialogHandle);
        }

        static public void CreateDockableDialog(this NotepadPPGateway editor, NppTbData data)
        {
            IntPtr _ptrNppTbData = Marshal.AllocHGlobal(Marshal.SizeOf(data));
            Marshal.StructureToPtr(data, _ptrNppTbData, false);

            Win32.SendMessage(editor.Handle, (uint)NppMsg.NPPM_DMMREGASDCKDLG, 0, _ptrNppTbData);
        }

        static public void AddToolbarIcon(this NotepadPPGateway editor, Bitmap icon, int handlerId)
        {
            var tbIcons = new toolbarIcons();
            tbIcons.hToolbarBmp = icon.GetHbitmap();
            IntPtr pTbIcons = Marshal.AllocHGlobal(Marshal.SizeOf(tbIcons));
            Marshal.StructureToPtr(tbIcons, pTbIcons, false);
            Win32.SendMessage(editor.Handle, (uint)NppMsg.NPPM_ADDTOOLBARICON, PluginBase._funcItems.Items[handlerId]._cmdID, pTbIcons);
            Marshal.FreeHGlobal(pTbIcons);
        }

        static public void DisplayInNewDocument(this NotepadPPGateway editor, string text)
        {
            editor.FileNew();

            var document = Npp.GetCurrentDocument();
            document.GrabFocus();
            document.AddText(text);
        }

        public static int GetCurrentLineNumber(this ScintillaGateway document)
        {
            return document.LineFromPosition(document.GetCurrentPos());
        }

        public static string GetCurrentLine(this ScintillaGateway document)
        {
            return document.GetLine(document.LineFromPosition(document.GetCurrentPos()));
        }

        static public string GetTextBetween(this ScintillaGateway document, Point point)
        {
            return GetTextBetween(document, point.X, point.Y);
        }

        static public string GetTextBetween(this ScintillaGateway document, int start, int end = -1)
        {
            if (end == -1)
                end = document.GetLength();

            using (var tr = new TextRange(start, end, end - start + 1)) //+1 for null termination
            {
                document.GetTextRange(tr);
                return tr.lpstrText;
            }
        }

        static public string TextBeforePosition(this ScintillaGateway document, int position, int maxLength)
        {
            int bufCapacity = maxLength + 1;
            int currentPos = position;
            int beginPos = currentPos - maxLength;
            int startPos = (beginPos > 0) ? beginPos : 0;
            int size = currentPos - startPos;

            if (size > 0)
            {
                using (var tr = new TextRange(startPos, currentPos, bufCapacity))
                {
                    document.GetTextRange(tr);
                    return tr.lpstrText;
                }
            }
            else
                return null;
        }

        static public string TextBeforeCursor(this ScintillaGateway document, int maxLength)
        {
            return document.TextBeforePosition(document.GetCurrentPos(), maxLength);
        }

        static public void SetTextBetween(this ScintillaGateway document, string text, Point point)
        {
            document.SetTextBetween(text, point.X, point.Y);
        }

        static public void SetTextBetween(this ScintillaGateway document, string text, int start, int end = -1)
        {
            //supposed not to scroll

            if (end == -1)
                end = document.GetLength();

            document.SetTargetStart(new Position(start));
            document.SetTargetEnd(new Position(end));
            document.ReplaceTarget(text.Length, text);
        }

        public static int CaretToTextPosition(this ScintillaGateway document, int position)
        {
            string text = document.GetTextBetween(0, position);
            return Encoding.UTF8.GetString(Encoding.UTF8.GetBytes(text)).Length;
        }

        public static string GetSelectedText(this ScintillaGateway document)
        {
            int start = document.GetSelectionStart();
            int end = document.GetSelectionEnd();
            return document.GetTextBetween(start, end);
        }

        static public int GetPositionFromLineColumn(this ScintillaGateway document, int line, int column)
        {
            return document.PositionFromLine(line) + column;
        }

        static public string GetWordAtCursor(this ScintillaGateway document, char[] wordDelimiters = null)
        {
            Point point;
            return document.GetWordAtCursor(out point, wordDelimiters);
        }

        static public string GetWordAtCursor(this ScintillaGateway document, out Point point, char[] wordDelimiters = null)
        {
            int currentPos = document.GetCurrentPos();
            return document.GetWordAtPosition(currentPos, out point, wordDelimiters);
        }

        static public string GetWordAtPosition(this ScintillaGateway document, int position, char[] wordDelimiters = null)
        {
            Point point;
            return document.GetWordAtPosition(position, out point, wordDelimiters);
        }

        static public string GetWordAtPosition(this ScintillaGateway document, int position, out Point point, char[] wordDelimiters = null)
        {
            int currentPos = position;
            int fullLength = document.GetLength();

            string leftText = document.TextBeforePosition(currentPos, 512);
            string rightText = document.TextAfterPosition(currentPos, 512);

            //if updating do not forger to update SimpleCodeCompletion.Delimiters
            var delimiters = "\\�\t\n\r .,:;'\"=[]{}()+-/!?@$%^&*��><#|~`".ToCharArray();

            if (wordDelimiters != null)
                delimiters = wordDelimiters;

            string wordLeftPart = "";
            int startPos = currentPos;

            if (leftText != null)
            {
                bool startOfDoc = leftText.Length == currentPos;
                startPos = leftText.LastIndexOfAny(delimiters);
                wordLeftPart = (startPos != -1) ? leftText.Substring(startPos + 1) : (startOfDoc ? leftText : "");
                int relativeStartPos = leftText.Length - startPos;
                startPos = (startPos != -1) ? (currentPos - relativeStartPos) + 1 : 0;
            }

            string wordRightPart = "";
            int endPos = currentPos;
            if (rightText != null)
            {
                endPos = rightText.IndexOfAny(delimiters);
                wordRightPart = (endPos != -1) ? rightText.Substring(0, endPos) : "";
                endPos = (endPos != -1) ? currentPos + endPos : fullLength;
            }

            point = new Point(startPos, endPos);
            return wordLeftPart + wordRightPart;
        }

        public static void SetSelection(this ScintillaGateway document, int start, int end)
        {
            document.SetSelectionStart(start);
            document.SetSelectionEnd(end);
        }

        static public void ScrollToCaret(this ScintillaGateway document)
        {
            document.ScrollCaret();
            document.LineScroll(0, 1); //bottom scrollbar can hide the line
            document.ScrollCaret();
        }

        public static void ReplaceSelection(this ScintillaGateway document, string text)
        {
            document.ReplaceSel(text); // the name is reflects well SCI message but looks unappealing
        }

        public static void MoveCaretTo(this ScintillaGateway document, int position)
        {
            document.SetCurrentPos(position);
            document.ClearSelection();
        }

        public static void ClearSelection(this ScintillaGateway document)
        {
            int currentPos = document.GetCurrentPos();
            document.SetSelectionStart(currentPos);
            document.SetSelectionEnd(currentPos);
        }

        [DllImport("user32")]
        public static extern bool ClientToScreen(IntPtr hWnd, ref Point lpPoint);

        [DllImport("user32")]
        public static extern bool ScreenToClient(IntPtr hWnd, ref Point lpPoint);

        static public Point GetCaretScreenLocation(this ScintillaGateway document)
        {
            int pos = document.GetCurrentPos();
            int x = document.PointXFromPosition(pos);
            int y = document.PointYFromPosition(pos);

            var point = new Point(x, y);
            ClientToScreen(document.Handle, ref point);
            return point;
        }

        static public int GetPositionFromMouseLocation(this ScintillaGateway document)
        {
            Point point = Cursor.Position;
            ScreenToClient(document.Handle, ref point);

            int pos = document.CharPositionFromPointClose(point.X, point.Y);
            return pos;
        }

        static public string TextAfterCursor(this ScintillaGateway document, int maxLength)
        {
            int currentPos = document.GetCurrentPos();
            return TextAfterPosition(document, currentPos, maxLength);
        }

        static public string TextAfterPosition(this ScintillaGateway document, int position, int maxLength)
        {
            int bufCapacity = maxLength + 1;
            int currentPos = position;
            int fullLength = document.GetLength();
            int startPos = currentPos;
            int endPos = Math.Min(currentPos + bufCapacity, fullLength);
            int size = endPos - startPos;

            if (size > 0)
            {
                using (var tr = new TextRange(startPos, endPos, bufCapacity))
                {
                    document.GetTextRange(tr);
                    return tr.lpstrText;
                }
            }
            else
                return null;
        }

        /// <summary>
        /// Open the file and navigate to the 0-based line and column position.
        /// </summary>
        /// <param name="file"></param>
        /// <param name="line"></param>
        /// <param name="column"></param>
        static public void NavigateToFileContent(this ScintillaGateway document, string file, int line, int column)
        {
            try
            {
                Npp.Editor.Open(file);
                document.GrabFocus();
                document.GotoLine(line); //SCI lines are 0-based

                //at this point the caret is at the most left position (col=0)
                var currentPos = document.GetCurrentPos();
                document.GotoPos(currentPos + column - 1);
            }
            catch { }
        }

        static public void OpenFile(this NotepadPPGateway editor, string file, bool grabFocus)
        {
            editor.Open(file);
            if (grabFocus)
                Npp.GetCurrentDocument().GrabFocus();
        }
    }
}