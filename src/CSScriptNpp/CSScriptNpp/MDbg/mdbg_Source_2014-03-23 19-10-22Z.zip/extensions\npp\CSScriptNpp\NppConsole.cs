﻿using System;
using System.Linq;
using System.Windows.Forms;
using Microsoft.Samples.Debugging.MdbgEngine;
using Microsoft.Samples.Tools.Mdbg.Extension;
using System.Diagnostics;

namespace gui
{
    public partial class NppConsole : Form
    {
        public NppDebugger debugger = new NppDebugger(null);

        public NppConsole()
        {
            InitializeComponent();
            debugger.OnPositionChanged += WriteLine;
        }

        void WriteLine(string text)
        {
            this.BeginInvoke((Action)delegate
            {
                lock (this)
                {
                    output.Text += text + "\r\n";
                }
            });
        }

        private void start_Click(object sender, EventArgs e)
        {
            debugger.Run(host.Text, args.Text, source.Text + "|" + lineNumber.Value);
        }

        private void insertBreakPoint_Click(object sender, EventArgs e)
        {
            debugger.CreateBreakPoint(source.Text, (int)lineNumber.Value);
        }

        private void go_Click(object sender, EventArgs e)
        {
            debugger.Go();
        }

        private void stepover_Click(object sender, EventArgs e)
        {
            debugger.StepOver();
        }

        private void stepin_Click(object sender, EventArgs e)
        {
            debugger.StepIn();
        }

        private void stepout_Click(object sender, EventArgs e)
        {
            debugger.StepOut();
        }

        private void pause_Click(object sender, EventArgs e)
        {
            debugger.Break();
        }
    }

}
