﻿namespace gui.CSScriptNpp
{
    partial class CmdInput
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CmdInput));
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.output = new System.Windows.Forms.TextBox();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.pause = new System.Windows.Forms.ToolStripButton();
            this.go = new System.Windows.Forms.ToolStripButton();
            this.stepover = new System.Windows.Forms.ToolStripButton();
            this.stepin = new System.Windows.Forms.ToolStripButton();
            this.stepout = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.button1 = new System.Windows.Forms.Button();
            this.lineNumber = new System.Windows.Forms.NumericUpDown();
            this.source = new System.Windows.Forms.ComboBox();
            this.insertBreakPoint = new System.Windows.Forms.Button();
            this.toolStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.lineNumber)).BeginInit();
            this.SuspendLayout();
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "mo nc on",
            "run \"E:\\Galos\\Projects\\MDbg\\Version_4\\MDbg Sample\\bin\\Debug\\test\\ConsoleApplicati" +
                "on12.exe\"",
            "go",
            "next",
            "out",
            "step",
            "suspend"});
            this.comboBox1.Location = new System.Drawing.Point(12, 28);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(525, 21);
            this.comboBox1.TabIndex = 1;
            this.comboBox1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBox1_KeyDown);
            // 
            // output
            // 
            this.output.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.output.Location = new System.Drawing.Point(12, 82);
            this.output.Multiline = true;
            this.output.Name = "output";
            this.output.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.output.Size = new System.Drawing.Size(637, 106);
            this.output.TabIndex = 2;
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.pause,
            this.go,
            this.stepover,
            this.stepin,
            this.stepout,
            this.toolStripButton1});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(661, 25);
            this.toolStrip1.TabIndex = 3;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // pause
            // 
            this.pause.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.pause.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.pause.Name = "pause";
            this.pause.Size = new System.Drawing.Size(40, 22);
            this.pause.Text = "break";
            this.pause.Click += new System.EventHandler(this.pause_Click);
            // 
            // go
            // 
            this.go.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.go.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.go.Name = "go";
            this.go.Size = new System.Drawing.Size(25, 22);
            this.go.Text = "go";
            this.go.Click += new System.EventHandler(this.go_Click);
            // 
            // stepover
            // 
            this.stepover.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.stepover.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.stepover.Name = "stepover";
            this.stepover.Size = new System.Drawing.Size(59, 22);
            this.stepover.Text = "step over";
            this.stepover.Click += new System.EventHandler(this.stepover_Click);
            // 
            // stepin
            // 
            this.stepin.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.stepin.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.stepin.Name = "stepin";
            this.stepin.Size = new System.Drawing.Size(46, 22);
            this.stepin.Text = "step in";
            this.stepin.Click += new System.EventHandler(this.stepin_Click);
            // 
            // stepout
            // 
            this.stepout.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.stepout.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.stepout.Name = "stepout";
            this.stepout.Size = new System.Drawing.Size(54, 22);
            this.stepout.Text = "step out";
            this.stepout.Click += new System.EventHandler(this.stepout_Click);
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton1.Image")));
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(30, 22);
            this.toolStripButton1.Text = "test";
            this.toolStripButton1.Click += new System.EventHandler(this.toolStripButton1_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(543, 26);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(106, 23);
            this.button1.TabIndex = 4;
            this.button1.Text = "Execute";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // lineNumber
            // 
            this.lineNumber.Location = new System.Drawing.Point(458, 55);
            this.lineNumber.Name = "lineNumber";
            this.lineNumber.Size = new System.Drawing.Size(79, 20);
            this.lineNumber.TabIndex = 7;
            this.lineNumber.Value = new decimal(new int[] {
            8,
            0,
            0,
            0});
            // 
            // source
            // 
            this.source.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.source.FormattingEnabled = true;
            this.source.Items.AddRange(new object[] {
            "E:\\Galos\\Projects\\MDbg\\Version_4\\MDbg Sample\\bin\\Debug\\test\\Script.cs",
            "c:\\Users\\osh\\Documents\\Visual Studio 2012\\Projects\\ConsoleApplication12\\ConsoleAp" +
                "plication12\\Program.cs"});
            this.source.Location = new System.Drawing.Point(12, 55);
            this.source.Name = "source";
            this.source.Size = new System.Drawing.Size(438, 21);
            this.source.TabIndex = 6;
            this.source.Text = "E:\\Galos\\Projects\\MDbg\\Version_4\\MDbg Sample\\bin\\Debug\\test\\Script.cs";
            // 
            // insertBreakPoint
            // 
            this.insertBreakPoint.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.insertBreakPoint.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.insertBreakPoint.Location = new System.Drawing.Point(543, 51);
            this.insertBreakPoint.Name = "insertBreakPoint";
            this.insertBreakPoint.Size = new System.Drawing.Size(106, 25);
            this.insertBreakPoint.TabIndex = 5;
            this.insertBreakPoint.Text = "Insert break point";
            this.insertBreakPoint.UseVisualStyleBackColor = true;
            this.insertBreakPoint.Click += new System.EventHandler(this.insertBreakPoint_Click);
            // 
            // CmdInput
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(661, 200);
            this.Controls.Add(this.lineNumber);
            this.Controls.Add(this.source);
            this.Controls.Add(this.insertBreakPoint);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.output);
            this.Controls.Add(this.comboBox1);
            this.Name = "CmdInput";
            this.Text = "CmdInput";
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.lineNumber)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.TextBox output;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton pause;
        private System.Windows.Forms.ToolStripButton go;
        private System.Windows.Forms.ToolStripButton stepover;
        private System.Windows.Forms.ToolStripButton stepin;
        private System.Windows.Forms.ToolStripButton stepout;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.NumericUpDown lineNumber;
        private System.Windows.Forms.ComboBox source;
        private System.Windows.Forms.Button insertBreakPoint;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
    }
}