﻿using Microsoft.Samples.Tools.Mdbg;
using Microsoft.Samples.Tools.Mdbg.Extension;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO.Pipes;
using System.Linq;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace gui.CSScriptNpp
{

    public partial class CmdInput : Form
    {
        DebuggerClient nppDebugger;

        public CmdInput(DebuggerClient nppDebugger)
        {
            InitializeComponent();
            this.nppDebugger = nppDebugger;
            nppDebugger.OnPositionChanged += WriteLine;
            nppDebugger.OnProcessExecution += started => WriteLine(started ? "Process started..." : "Process exited...");
        }

        void WriteLine(string text)
        {
            Invoke((Action)delegate
            {
                output.Text += text + Environment.NewLine;
            });
        }

        private void textBox1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Return)
            {
                ExecuteCurrentCommand();
            }
        }

        void ExecuteCurrentCommand()
        {
            nppDebugger.ExecuteCommand(comboBox1.Text);
            comboBox1.Text = null;
        }

        private void pause_Click(object sender, EventArgs e)
        {
            nppDebugger.Break();
        }

        private void go_Click(object sender, EventArgs e)
        {
            nppDebugger.Go();
        }

        private void stepover_Click(object sender, EventArgs e)
        {
            nppDebugger.StepOver();
        }

        private void stepin_Click(object sender, EventArgs e)
        {
            nppDebugger.StepIn();
        }

        private void stepout_Click(object sender, EventArgs e)
        {
            nppDebugger.StepOut();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ExecuteCurrentCommand();
        }

        private void insertBreakPoint_Click(object sender, EventArgs e)
        {
            nppDebugger.CreateBreakPoint(source.Text, (int)lineNumber.Value);
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            nppDebugger.Test();
        }
    }
}
