﻿namespace gui
{
    partial class NppConsole
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.output = new System.Windows.Forms.TextBox();
            this.pause = new System.Windows.Forms.ToolStripButton();
            this.go = new System.Windows.Forms.ToolStripButton();
            this.stepover = new System.Windows.Forms.ToolStripButton();
            this.stepin = new System.Windows.Forms.ToolStripButton();
            this.stepout = new System.Windows.Forms.ToolStripButton();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.start = new System.Windows.Forms.Button();
            this.host = new System.Windows.Forms.ComboBox();
            this.args = new System.Windows.Forms.ComboBox();
            this.source = new System.Windows.Forms.ComboBox();
            this.insertBreakPoint = new System.Windows.Forms.Button();
            this.lineNumber = new System.Windows.Forms.NumericUpDown();
            this.toolStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.lineNumber)).BeginInit();
            this.SuspendLayout();
            // 
            // output
            // 
            this.output.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.output.Location = new System.Drawing.Point(0, 111);
            this.output.Multiline = true;
            this.output.Name = "output";
            this.output.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.output.Size = new System.Drawing.Size(685, 300);
            this.output.TabIndex = 0;
            // 
            // pause
            // 
            this.pause.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.pause.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.pause.Name = "pause";
            this.pause.Size = new System.Drawing.Size(40, 22);
            this.pause.Text = "break";
            this.pause.Click += new System.EventHandler(this.pause_Click);
            // 
            // go
            // 
            this.go.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.go.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.go.Name = "go";
            this.go.Size = new System.Drawing.Size(25, 22);
            this.go.Text = "go";
            this.go.Click += new System.EventHandler(this.go_Click);
            // 
            // stepover
            // 
            this.stepover.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.stepover.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.stepover.Name = "stepover";
            this.stepover.Size = new System.Drawing.Size(59, 22);
            this.stepover.Text = "step over";
            this.stepover.Click += new System.EventHandler(this.stepover_Click);
            // 
            // stepin
            // 
            this.stepin.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.stepin.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.stepin.Name = "stepin";
            this.stepin.Size = new System.Drawing.Size(46, 22);
            this.stepin.Text = "step in";
            this.stepin.Click += new System.EventHandler(this.stepin_Click);
            // 
            // stepout
            // 
            this.stepout.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.stepout.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.stepout.Name = "stepout";
            this.stepout.Size = new System.Drawing.Size(54, 22);
            this.stepout.Text = "step out";
            this.stepout.Click += new System.EventHandler(this.stepout_Click);
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.pause,
            this.go,
            this.stepover,
            this.stepin,
            this.stepout});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(685, 25);
            this.toolStrip1.TabIndex = 1;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // start
            // 
            this.start.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.start.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.start.Location = new System.Drawing.Point(573, 29);
            this.start.Name = "start";
            this.start.Size = new System.Drawing.Size(106, 48);
            this.start.TabIndex = 2;
            this.start.Text = "start";
            this.start.UseVisualStyleBackColor = true;
            this.start.Click += new System.EventHandler(this.start_Click);
            // 
            // host
            // 
            this.host.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.host.FormattingEnabled = true;
            this.host.IntegralHeight = false;
            this.host.Items.AddRange(new object[] {
            "E:\\Galos\\Projects\\MDbg\\Version_4\\MDbg Sample\\bin\\Debug\\test\\css_dbg.exe"});
            this.host.Location = new System.Drawing.Point(4, 29);
            this.host.Name = "host";
            this.host.Size = new System.Drawing.Size(562, 21);
            this.host.TabIndex = 3;
            this.host.Text = "E:\\Galos\\Projects\\MDbg\\Version_4\\MDbg Sample\\bin\\Debug\\test\\css_dbg.exe";
            // 
            // args
            // 
            this.args.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.args.FormattingEnabled = true;
            this.args.Items.AddRange(new object[] {
            "/nl /dbg /l \"E:\\Galos\\Projects\\MDbg\\Version_4\\MDbg Sample\\bin\\Debug\\test\\Script.c" +
                "s\""});
            this.args.Location = new System.Drawing.Point(4, 56);
            this.args.Name = "args";
            this.args.Size = new System.Drawing.Size(562, 21);
            this.args.TabIndex = 3;
            this.args.Text = "/nl /dbg /l \"E:\\Galos\\Projects\\MDbg\\Version_4\\MDbg Sample\\bin\\Debug\\test\\Script.c" +
    "s\"";
            // 
            // source
            // 
            this.source.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.source.FormattingEnabled = true;
            this.source.Items.AddRange(new object[] {
            "E:\\Galos\\Projects\\MDbg\\Version_4\\MDbg Sample\\bin\\Debug\\test\\Script.cs"});
            this.source.Location = new System.Drawing.Point(4, 83);
            this.source.Name = "source";
            this.source.Size = new System.Drawing.Size(476, 21);
            this.source.TabIndex = 3;
            this.source.Text = "E:\\Galos\\Projects\\MDbg\\Version_4\\MDbg Sample\\bin\\Debug\\test\\Script.cs";
            // 
            // insertBreakPoint
            // 
            this.insertBreakPoint.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.insertBreakPoint.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.insertBreakPoint.Location = new System.Drawing.Point(573, 80);
            this.insertBreakPoint.Name = "insertBreakPoint";
            this.insertBreakPoint.Size = new System.Drawing.Size(106, 25);
            this.insertBreakPoint.TabIndex = 2;
            this.insertBreakPoint.Text = "insert break point";
            this.insertBreakPoint.UseVisualStyleBackColor = true;
            this.insertBreakPoint.Click += new System.EventHandler(this.insertBreakPoint_Click);
            // 
            // lineNumber
            // 
            this.lineNumber.Location = new System.Drawing.Point(487, 83);
            this.lineNumber.Name = "lineNumber";
            this.lineNumber.Size = new System.Drawing.Size(79, 20);
            this.lineNumber.TabIndex = 4;
            this.lineNumber.Value = new decimal(new int[] {
            8,
            0,
            0,
            0});
            // 
            // NppConsole
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(685, 413);
            this.Controls.Add(this.lineNumber);
            this.Controls.Add(this.source);
            this.Controls.Add(this.args);
            this.Controls.Add(this.host);
            this.Controls.Add(this.insertBreakPoint);
            this.Controls.Add(this.start);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.output);
            this.Name = "NppConsole";
            this.Text = "NppConsole";
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.lineNumber)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox output;
        private System.Windows.Forms.ToolStripButton pause;
        private System.Windows.Forms.ToolStripButton go;
        private System.Windows.Forms.ToolStripButton stepover;
        private System.Windows.Forms.ToolStripButton stepin;
        private System.Windows.Forms.ToolStripButton stepout;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.Button start;
        private System.Windows.Forms.ComboBox host;
        private System.Windows.Forms.ComboBox args;
        private System.Windows.Forms.ComboBox source;
        private System.Windows.Forms.Button insertBreakPoint;
        private System.Windows.Forms.NumericUpDown lineNumber;
    }
}