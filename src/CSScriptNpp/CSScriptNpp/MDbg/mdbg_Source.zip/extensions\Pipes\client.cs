using System.Threading;
using System.Threading.Tasks;
using System;
using System.IO;
using System.IO.Pipes;

class PipeClient
{
    static void Main(string[] args)
    {
        Task.Factory.StartNew(HandleCommands);
        Task.Factory.StartNew(NotifyOnEvents);

        Console.Write("Press Enter to continue...");
        Console.ReadLine();
    }

    static void HandleCommands()
    {
        using (var pipeClient = new NamedPipeClientStream(".", "testpipe.inout", PipeDirection.InOut))
        using (var reader = new StreamReader(pipeClient))
        using (var writer = new StreamWriter(pipeClient))
        {
            pipeClient.Connect();
            Console.WriteLine("Connected as InOut.Client.");

            writer.AutoFlush = true;

            string temp;
            while ((temp = reader.ReadLine()) != null)
            {
                Console.WriteLine("Received from server: {0}", temp);

                writer.WriteLine(temp);
                pipeClient.WaitForPipeDrain();
            }
        }
    }

    static void NotifyOnEvents()
    {
        using (var pipeClient = new NamedPipeClientStream(".", "testpipe.in", PipeDirection.Out))
        using (var writer = new StreamWriter(pipeClient))
        {
            pipeClient.Connect();
            Console.WriteLine("Connected as In.Client.");
            writer.AutoFlush = true;

            while(true)
            {
                Thread.Sleep(5000);
                writer.WriteLine("Event: "+ Environment.TickCount);
                pipeClient.WaitForPipeDrain();
            }
        }
    }
}