using System.Threading;
using System.Threading.Tasks;
using System;
using System.IO;
using System.IO.Pipes;

class PipeServer
{
    static bool clientConnected;
    static void Main()
    {
        Task.Factory.StartNew(PushCommands);
        Task.Factory.StartNew(ReceiveNotifications);

        do
        {
            Thread.Sleep(5000);
        }
        while(clientConnected);

        Console.Write("Press Enter to continue...");
        Console.ReadLine();
    }

    static void ReceiveNotifications()
    {
        try
        {
            using (var pipeServer = new NamedPipeServerStream("testpipe.in", PipeDirection.In))
            using (var streamReader = new StreamReader(pipeServer))
            {
                pipeServer.WaitForConnection();
                clientConnected = true;
                Console.WriteLine("In.Client connected.");

                while(clientConnected)
                {
                    string message = streamReader.ReadLine();
                    if(message == null)
                        clientConnected = false;
                    else
                        Console.WriteLine("\n[Notification]: " + message);
                }
            }
        }
        catch (IOException e)
        {
            Console.WriteLine("ERROR: {0}", e.Message);
        }

        Console.WriteLine("In.Client disconnected.");
    }

    static void PushCommands()
    {
        try
        {
            using (var pipeServer = new NamedPipeServerStream("testpipe.inout", PipeDirection.InOut))
            using (var streamWriter = new StreamWriter(pipeServer))
            using (var streamReader = new StreamReader(pipeServer))
            {
                pipeServer.WaitForConnection();
                clientConnected = true;
                Console.WriteLine("InOut.Client connected.");
                streamWriter.AutoFlush = true;

                while(clientConnected)
                {
                    Console.Write("Enter text: ");
                    string command = Console.ReadLine();

                    if(clientConnected)
                    {
                        streamWriter.WriteLine(command);

                        pipeServer.WaitForPipeDrain();

                        string response = streamReader.ReadLine();
                        if(response == null)
                            clientConnected = false;
                        else
                            Console.WriteLine("\n[Command]: " + response);
                    }
                }
            }
        }
        catch (IOException e)
        {
            Console.WriteLine("ERROR: {0}", e.Message);
        }

        Console.WriteLine("InOut.Client disconnected.");
    }
}