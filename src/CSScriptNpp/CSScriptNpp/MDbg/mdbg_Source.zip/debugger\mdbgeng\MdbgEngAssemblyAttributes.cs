
// Attributes for MdbgEngine

using System;
using System.Threading;
using System.Diagnostics;
using System.Collections;
using System.Security.Permissions;

[assembly:CLSCompliant(true)]
[assembly:System.Runtime.InteropServices.ComVisible(false)]
[assembly:SecurityPermission(SecurityAction.RequestMinimum, Unrestricted=true)]
