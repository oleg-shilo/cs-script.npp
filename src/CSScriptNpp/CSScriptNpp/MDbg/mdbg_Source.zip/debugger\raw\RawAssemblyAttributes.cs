//---------------------------------------------------------------------
//  This file is part of the CLR Managed Debugger (mdbg) Sample.
// 
//  Copyright (C) Microsoft Corporation.  All rights reserved.
//
// Imports ICorDebug interface into managed code
//---------------------------------------------------------------------


// Assembly attributes for Raw native imports.
using System;
[assembly:CLSCompliant(false)]
