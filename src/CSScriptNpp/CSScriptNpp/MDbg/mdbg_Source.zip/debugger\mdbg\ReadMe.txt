//---------------------------------------------------------------------
//  This file is part of the CLR Managed Debugger (mdbg) Sample.
// 
//  Copyright (C) Microsoft Corporation.  All rights reserved.
//---------------------------------------------------------------------

ReadMe.txt for mdbg project.

This is the actual Managed Debugger (mdbg) application.
This contains the commands and exe level code that calls into all the other libraries.

Once the program is compiled it can be used to debug other managed programs.
