//---------------------------------------------------------------------
//  This file is part of the CLR Managed Debugger (mdbg) Sample.
// 
//  Copyright (C) Microsoft Corporation.  All rights reserved.
//---------------------------------------------------------------------

ReadMe.txt for gui project.

This is a loadable extension.  Type "load gui" in mdbg to get this functionality.

It provides a Graphical User Interface for mdbg.
For example, rather than needing to occasionally "show" while you step through the source, you can see the code as you go.