﻿//---------------------------------------------------------------------
//  This file is part of the CLR Managed Debugger (mdbg) Sample.
// 
//  Copyright (C) Microsoft Corporation.  All rights reserved.
//---------------------------------------------------------------------
#region Using directives

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

#endregion

using System.Globalization;
using Microsoft.Samples.Tools.Mdbg;
using Microsoft.Samples.Debugging.MdbgEngine;
using Microsoft.Samples.Tools.Mdbg.Extension;
using Microsoft.Samples.Debugging.CorDebug.NativeApi;

namespace gui
{
    partial class AutoWatchWindow : DebuggerToolWindow
    {
        public AutoWatchWindow(MainForm mainForm)
            : base(mainForm)
        {
            InitializeComponent();
            // Hook handler for lazily expanding
            treeView1.BeforeExpand += new TreeViewCancelEventHandler(treeView1_BeforeSelect);
        }

        // Called On UI thread.
        void treeView1_BeforeSelect(object sender, TreeViewCancelEventArgs e)
        {
            Util.TryExpandNode(MainForm, e.Node);
        }

        // Called On UI thread.
        protected override void RefreshToolWindowInternal()
        {
            MDbgFrame frame = null;

            MDbgValue[] locals = null;
            MDbgValue[] args = null;

            MainForm.ExecuteOnWorkerThreadIfStoppedAndBlock(delegate(MDbgProcess proc)
            {
                frame = GetCurrentFrame(proc);
                if (frame == null)
                {
                    return;
                }

                // Add Vars to window.            
                MDbgFunction f = frame.Function;

                locals = f.GetActiveLocalVars(frame);
                args = f.GetArguments(frame);

                if (IsEvalSafe(proc))
                    EvalWatch(proc);
            });

            if (frame == null)
            {
                return;
            }

            // Reset
            TreeView t = this.treeView1;
            t.BeginUpdate();
            t.Nodes.Clear();

            // Add Vars to window.            
            if (locals != null)
            {
                foreach (MDbgValue v in locals)
                {
                    Util.PrintInternal(MainForm, v, t.Nodes);
                }
            }

            if (args != null)
            {
                foreach (MDbgValue v in args)
                {
                    Util.PrintInternal(MainForm, v, t.Nodes);
                }
            }

            t.EndUpdate();


        } // refresh

        bool IsSet(CorDebugUserState value, CorDebugUserState bitValue)//zos; CSScript.Npp related changes
        {
            return (value | bitValue) == value;
        }

        bool IsEvalSafe(MDbgProcess proc)//zos; CSScript.Npp related changes
        {
            //Process.AsyncStop().WaitOne();

            ICorDebugThread dbgThred = proc.Threads.Active.CorThread.Raw;

            ///http://blogs.msdn.com/b/jmstall/archive/2005/11/15/funceval-rules.aspx
            ///Dangers of Eval: http://blogs.msdn.com/b/jmstall/archive/2005/03/23/400794.aspx
            CorDebugUserState pState;
            dbgThred.GetUserState(out pState);
            if ((!IsSet(pState, CorDebugUserState.USER_UNSAFE_POINT) && IsSet(pState, CorDebugUserState.USER_STOPPED)) || pState == CorDebugUserState.USER_NONE)
            //if (!IsSet(pState, CorDebugUserState.USER_UNSAFE_POINT) && IsSet(pState, CorDebugUserState.USER_STOPPED))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        void EvalWatch(MDbgProcess proc)
        {
            Console.WriteLine("-------------------");
            string expressionValue = "";
            try
            {
                //public class Test { public int MyPorp { get; set; } }
                //...
                //var t = new Test();                            
                //t.MyPorp = 9;
                string expression = "t.MyCount";

                MDbgValue value = proc.ResolveVariable(expression, proc.Threads.Active.CurrentFrame);

                if (value != null)
                {
                    Console.WriteLine(expression + ": " + value.GetStringValue(false));
                }
                Console.WriteLine("#################");
            }
            catch
            {
                //expressionValue = "<items/>";
                Console.WriteLine("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            }
            Console.WriteLine("-------------------");
        }
    } // AutoWatchWindow
}